var alphabet = prompt("Enter from A to D");
switch (alphabet) {
case 'A':
    alert("Excellent");
break;
case 'B':
    alert("Good");
break;
case 'C':
    alert("Fair");
break;
case 'D':
    alert("Poor");
break;
default:
   alert("invalid input");
}

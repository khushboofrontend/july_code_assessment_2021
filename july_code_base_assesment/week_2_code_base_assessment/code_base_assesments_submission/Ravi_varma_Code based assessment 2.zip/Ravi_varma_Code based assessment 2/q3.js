var text1, array_length, counter;
var Name_array = ["Amar", "Raja", "Rani"];
var score_array = ["Chennai", "Delhi", "Banglore"];
array_length = Name_array.length;
text1 = '<table border="1" cellspacing="0" cellpadding="5">';
text1 += "<tr><th>Name</th><th>Place</th></tr>";
for (counter = 0; counter < array_length; counter++) {
    text1 += "<tr><td>" + Name_array[counter] + "</td><td>" + score_array[counter] + "</td></tr>";
}
text1 += "</table>";
document.getElementById("div1").innerHTML = text1;

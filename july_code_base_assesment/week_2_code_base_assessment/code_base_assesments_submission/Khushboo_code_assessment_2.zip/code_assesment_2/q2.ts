var input1 = prompt("Please enter an alphabet : ");
if (input1=="A"){
    alert("Excellent")
}
else if(input1=="B"){
    alert("Good")
}
else if(input1=="C"){
    alert("Fair")
}
else if(input1=="D"){
    alert("Poor")
}
else{
    alert("Invalid Input")
}
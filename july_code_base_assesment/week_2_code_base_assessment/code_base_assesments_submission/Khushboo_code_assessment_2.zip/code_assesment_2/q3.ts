var myArray = [
    { name:"Khushi", place:"Indore"},
    { name:"Rakhi", place:"Bhopal"},
    { name:"Rohit", place:"Ujjain"}
]
console.log(myArray)
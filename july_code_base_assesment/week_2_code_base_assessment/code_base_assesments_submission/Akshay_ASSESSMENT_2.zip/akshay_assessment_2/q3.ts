var text, array_length, i;
var Name_array = ["Amar","Raja","Rani"];
var score_array = ["Chennai","Delhi","Banglore"];
array_length = Name_array.length;
text= '<table border="1" cellspacing="0" cellpadding="5">';
text += "<tr><th>Name</th><th>Place</th></tr>"
for( i = 0; i < array_length; i++) {
  text += "<tr><td>" + Name_array[i] + "</td><td>" + score_array[i] + "</td></tr>";
}
text += "</table>";
document.getElementById("div1").innerHTML = text;
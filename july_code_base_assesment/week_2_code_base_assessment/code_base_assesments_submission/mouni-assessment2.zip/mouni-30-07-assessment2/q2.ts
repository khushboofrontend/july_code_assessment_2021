  var letter: string;  
  letter = prompt('Enter a letter')
  switch (letter)
   {  
   case 'A': 
        alert("Excellent")
        break;  
   case 'B': 
        alert("Good")  
        break;  
   case 'C':  
        alert("Fair") 
        break;  
   case 'D': 
        alert("Poor")  
        break;    
   default:  
        alert("invalid input........")  
  }
 